#!/bin/bash

# Script for User Information:

echo "Username: $USER"
echo "User ID (UID): $(id -u)"
echo "Group ID (GID): $(id -g)"
echo "Home Directory: $HOME"
echo "Shell: $SHELL"

# To execute the file
#chmod +x User_information.sh

