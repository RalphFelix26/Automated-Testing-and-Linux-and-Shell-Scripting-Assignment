#!/bin/bash

# Create directory structure
sudo mkdir -p home/user/(projects,documents,downloads)
# To make it executable

# To create subdirectories structure
sudo mkdir -p home/user/projects/{project1,project2, projects3}

# To execute the file
#chmod +x Dir_structure.sh
