#!/bin/bash

# To process monitor

PROCESS_NAME="apache2"
LOG_FILE="/var/log/process_monitor.log"


log_message() {
    echo "$(date '+%Y-%m-%d %H:%M:%S')" >> "$LOG_FILE"
}

if ! pgrep -x "$PROCESS_NAME" > /dev/null; then
    systemctl start "$PROCESS_NAME"
    log_message "$PROCESS_NAME was not running and has been started."

else
    log_message "$PROCESS_NAME is running."
fi

# For executing the file 

# Chmod +x Process_monitor.sh
