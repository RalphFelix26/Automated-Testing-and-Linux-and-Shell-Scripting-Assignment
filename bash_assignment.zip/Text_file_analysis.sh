#!/bin/bash

# For analysing a text file


FILE="\$1"

# Count lines, words, and characters
LINE_COUNT=$(wc -l < "$FILE")
WORD_COUNT=$(wc -w < "$FILE")
CHAR_COUNT=$(wc -c < "$FILE")

# Display the counts
echo "File: $FILE"
echo "Lines: $LINE_COUNT"
echo "Words: $WORD_COUNT"
echo "Characters: $CHAR_COUNT"


# To execute the file
#chmod +x Text_file_analysis.sh
 

