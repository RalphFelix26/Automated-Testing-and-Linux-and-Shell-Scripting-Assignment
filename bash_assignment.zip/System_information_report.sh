#!/bin/bash

OUTPUT_FILE="system_report.txt"

# Create or clear the report file
echo "System Information Report" > "$OUTPUT_FILE"
echo "" >> "$OUTPUT_FILE"

# Get system uptime
echo "System Uptime:" >> "$OUTPUT_FILE"
uptime >> "$OUTPUT_FILE"
echo "" >> "$OUTPUT_FILE"

# Get memory usage
echo "Memory Usage:" >> "$OUTPUT_FILE"
free -h >> "$OUTPUT_FILE"
echo "" >> "$OUTPUT_FILE"

# Get CPU load
echo "CPU Load:" >> "$OUTPUT_FILE"
top -bn1 | grep "Cpu(s)" >> "$OUTPUT_FILE"
echo "" >> "$OUTPUT_FILE"

# Get disk usage
echo "Disk Usage:" >> "$OUTPUT_FILE"
df -h >> "$OUTPUT_FILE"
echo "" >> "$OUTPUT_FILE"

# Get running processes
echo "Running Processes:" >> "$OUTPUT_FILE"
ps aux >> "$OUTPUT_FILE"
echo "" >> "$OUTPUT_FILE"

echo "System information report saved to $OUTPUT_FILE"

# To execute the file
#chmod +x System_information_report.sh

