#!/bin/bash 

#Disk Usage Alert

THRESHOLD=50

USAGE=$(df / | grep / | awk '{ print \$5 }' | sed 's/%//g')
do

if [ "$USAGE" -gt "$THRESHOLD" ]; then

    SUBJECT="Disk Usage Alert"
    TO="ralphfelix26@gmail.com"
    BODY="Warning! Disk usage is ${USAGE}% full. Please free up space."

    echo "$BODY" | mail -s "$SUBJECT" "$TO"
fi
