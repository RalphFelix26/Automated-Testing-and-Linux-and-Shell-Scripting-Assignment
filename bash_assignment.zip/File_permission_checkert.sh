#!/bin/bash

#File Permission Checker
if [ "$#" -ne 1 ]; then
    echo "Enter file name"
    exit 1
fi

FILE="\$1"


if [ -r "$FILE" ]; then
    echo "Read permission: Granted"
else
    echo "Read permission: Denied"
fi

if [ -w "$FILE" ]; then
    echo "Write permission: Granted"
else
    echo "Write permission: Denied"
fi

if [ -x "$FILE" ]; then
    echo "Execute permission: Granted"
else
    echo "Execute permission: Denied"
fi


# To execute the file
#chmod +x File_permission_checker
