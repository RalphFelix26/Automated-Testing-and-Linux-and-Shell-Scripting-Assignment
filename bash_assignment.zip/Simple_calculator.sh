#!/bin/bash

calculate() {
    case \$3 in
        +)
            echo "\$1 + \$2 = $(echo "\$1 + \$2" | bc)"
            ;;
        -)
            echo "\$1 - \$2 = $(echo "\$1 - \$2" | bc)"
            ;;
        \*)
            echo "\$1 * \$2 = $(echo "\$1 * \$2" | bc)"
            ;;
        /)
            if [ "\$2" -eq 0 ]; then
                echo "Error: Division by zero is not allowed."
            else
                echo "\$1 / \$2 = $(echo "scale=2; \$1 / \$2" | bc)"
            fi
            ;;
        *)
            echo "Error: Invalid operator. Please use +, -, *, or /."
            ;;
    esac
}

# Prompt the user for input
read -p "Enter the first number: " num1
read -p "Enter the second number: " num2
read -p "Enter an operator (+, -, *, /): " operator

# Call the calculate function
calculate "$num1" "$num2" "$operator"

# To execute the file
#chmod +x Simple_calculator.sh

