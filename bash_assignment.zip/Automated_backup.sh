#!/bin/bash

# To create a daily automated backup of directory

SOURCE_DIR="/home/user/documents"
BACKUP_DIR="/home/user/backup"
BACKUP_FILE="documents_backup.tar.gz"

# Create the backup directory 
mkdir -p "$BACKUP_DIR"

# Compress the documents directory into a tarball
tar -czf "$BACKUP_DIR/$BACKUP_FILE" -C "$SOURCE_DIR" .

# To execute the file
#chmod +x Automated_backup.sh


# For running the backup by using Cron
#cron -e
#0 22 * * * /home/user/File_backup.sh

