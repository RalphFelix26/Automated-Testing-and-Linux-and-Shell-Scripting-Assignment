#!/bin/bash

SOURCE_DIR="\$1"

#  To create backup.txt files with time stamp

if [ "$#" -ne 1 ]; then
    echo "Usage: \$0 <directory>"
    exit 1
fi

# Input directory 
directory=$1

timestamp=$(date +"%Y%m%d_%H%M%S")
backup_dir="$directory/backup_$timestamp"
mkdir "$backup_dir"


find "$1" -type f -name "*.txt" -exec cp {} "$backup_dir" \;

echo "Backup of .txt files completed successfully in $backup_dir."

# To execute the file
#chmod +x  File_backup.sh


